#ifndef Output_H
#define Output_H

void Print_Screen();
void Print_File(); 

FILE *fp;
clock_t Running_Time;

#endif
